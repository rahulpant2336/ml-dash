from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import mysql.connector

import hashlib
import datetime
import json
import pickle
import numpy as np
import requests
import yaml

app = Flask(__name__)
db = yaml.load(open('db.yaml'))
# Load the model
#model = pickle.load(open('model.pkl','rb'))
app.secret_key = '3242353645646'

mydb = mysql.connector.connect(
  host=db['mysql_host'],
  user=db['mysql_user'],
  passwd=db['mysql_password'],
  database=db['mysql_db']
)


#app.config['MYSQL_HOST'] = db['mysql_host']
#app.config['MYSQL_USER'] = db['mysql_user']
#app.config['MYSQL_PASSWORD'] = db['mysql_password']
#app.config['MYSQL_DB'] = db['mysql_db']


#mysql = MySQL(mydb)


#conn = sqlite3.connect('database.db')
#conn.execute('CREATE TABLE users (name TEXT, email TEXT, password TEXT)')
#cur = conn.cursor()
#cur.execute("INSERT INTO users (name,email,password) VALUES (?,?,?)",('Rahul','rahul.pant@adaan.com','rahul2336') )
#conn.commit()






@app.route('/')
def Index():
    mycursor = mydb.cursor()
    mycursor.execute("SELECT  job_category FROM jobs WHERE status='Enable'")
    data = mycursor.fetchall()
    mycursor.close()
    return render_template('register.html', jobs=data)



@app.route('/register', methods = ['POST'])
def insert():

    if request.method == "POST":
        first_name = request.form['first_name']
        middle_name = request.form['middle_name']
        last_name = request.form['last_name']
        email = request.form['email']
        phone = request.form['phone']
        position_applied = request.form['position_applied']
        password = hashlib.md5(request.form['password'].encode())
        password_save = password.hexdigest()
        role = 2
        confirm_password = hashlib.md5(request.form['confirm_password'].encode())
        confirm_password_save = confirm_password.hexdigest()
        cur = mydb.cursor(dictionary=True)
        sql = "SELECT * FROM students WHERE email ='"+email+"'"
        cur.execute(sql)
        myresult = cur.fetchall()
        if not myresult:
            cur.execute("INSERT INTO students (first_name, middle_name, last_name, email, phone, position_applied, password, confirm_password, role) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                        (first_name, middle_name, last_name, email, phone, position_applied, password_save, confirm_password_save, role))
            mydb.commit()
            flash("Registration success!!!")
            return render_template('register.html', success="success")
        else:
            flash("Email Already Registered!!!")
            return render_template('register.html', success="error")



@app.route('/login')
def login():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    else:
        return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return render_template('modle.html', now=datetime.datetime.now())
    else:
        return redirect(url_for('login'))





def check_password(hashed_password, user_password):
    return hashed_password == hashlib.md5(user_password.encode()).hexdigest()

def validate(username, password):

    completion = False

    cur = mydb.cursor(dictionary=True)
    cur.execute("SELECT * FROM students")
    data = cur.fetchall()
    print(data)
    for row in data:
        dbUser = row['email']
        dbPass = row['password']
        if dbUser==username:
            completion=check_password(dbPass, password)

    return completion





@app.route('/login-check', methods = ['POST'])
def checkLogin():
    error = None
    if request.method == 'POST':
        error = None
        email = request.form['email']
        password = request.form['password']
        completion = validate(email, password)
        if completion ==False:
            flash("Invalid Credentials. Please try again.")
            return render_template('login.html')
        else:
            cur = mydb.cursor(dictionary=True)
            cur.execute("SELECT * FROM students WHERE email ='"+email+"'")
            data = cur.fetchall()
            print(data)
            session['username'] = data
            return redirect(url_for('dashboard'))

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))






if __name__ == "__main__":
    app.run(debug=True)
